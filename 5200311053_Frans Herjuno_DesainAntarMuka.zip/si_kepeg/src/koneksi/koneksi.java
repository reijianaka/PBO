/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi;

import java.sql.*;
/**
 *
 * @author acer
 */
public class koneksi {
    private static Connection koneksi;
    
    public static Connection getKoneksi(){
        if (koneksi == null) {
            try {
                String url = "jdbc:mysql://localhost:3306/pbolpegawai";
                String username = "root";
                String password = "";
                
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                
                koneksi = DriverManager.getConnection(url,username,password);
                System.out.println("Koneksi ke database berhasil");
                
            } catch (SQLException e) {
                System.out.println("Koneksi ke database Gagal!!");
               
            }            
        }
        return koneksi;
    }    
}
